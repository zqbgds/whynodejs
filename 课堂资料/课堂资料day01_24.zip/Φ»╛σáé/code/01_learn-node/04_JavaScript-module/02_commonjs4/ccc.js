console.log('ccc');

require('./ddd');
