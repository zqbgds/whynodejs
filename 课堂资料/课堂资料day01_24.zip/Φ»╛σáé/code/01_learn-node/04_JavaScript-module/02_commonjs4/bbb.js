console.log('bbb');

require('./ccc');