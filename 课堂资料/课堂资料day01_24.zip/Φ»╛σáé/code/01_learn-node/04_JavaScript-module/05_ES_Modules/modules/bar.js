// import {name, age, sayHello} from './foo.js';

// export {
//   name,
//   age, 
//   sayHello
// }

export {name, age, sayHello} from './foo.js';
