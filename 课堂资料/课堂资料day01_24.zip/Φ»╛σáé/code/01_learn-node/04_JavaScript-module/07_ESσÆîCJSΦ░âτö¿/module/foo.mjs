const name = "coderwhy";
const age = 18;

export {
  name,
  age
}