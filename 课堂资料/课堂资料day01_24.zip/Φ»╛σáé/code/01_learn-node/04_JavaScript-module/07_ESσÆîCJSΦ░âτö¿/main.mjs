import foo from './module/bar.js';

console.log(foo.name);
