console.log(require('./bar'));

console.log(module);

