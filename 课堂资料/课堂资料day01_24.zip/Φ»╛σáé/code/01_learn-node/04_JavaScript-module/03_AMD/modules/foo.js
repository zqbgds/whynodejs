define(['bar'], function(bar) {
  console.log(bar.name);
  console.log(bar.age);
  bar.sayHello("kobe");
});
