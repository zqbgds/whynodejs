define(function() {
  const name = "coderwhy";
  const age = 18;
  const sayHello = function(name) {
    console.log("你好" + name);
  }

  return {
    name,
    age,
    sayHello
  }
});