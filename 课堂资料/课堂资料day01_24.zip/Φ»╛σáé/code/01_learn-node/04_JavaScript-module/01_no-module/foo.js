(function() {
  var name = "小丽";

  console.log(name);
})();
