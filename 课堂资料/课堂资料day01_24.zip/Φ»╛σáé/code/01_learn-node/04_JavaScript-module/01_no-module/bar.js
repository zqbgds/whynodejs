// 1000行

var moduleBar = (function () {
  var name = "小明";
  var age = 18;

  console.log(name);

  return {
    name,
    age
  }
})()
