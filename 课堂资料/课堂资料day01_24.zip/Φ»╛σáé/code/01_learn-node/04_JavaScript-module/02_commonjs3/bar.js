
let name = "why";
console.log(name);

name = "coderwhy";
console.log(name);
