console.log(global);

var name = "coderwhy";
console.log(name);
console.log(global.name);

console.log(global.process);

