
const name = '';
console.log(!name);
